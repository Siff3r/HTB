#!/bin/bash
chmod 777 /etc/passwd
